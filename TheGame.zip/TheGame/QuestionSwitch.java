package TheGame;
public class QuestionSwitch {
    public static void switchToNextQuestion() {
        System.out.println("Tiden ärtyvärr slut för den här frågan!");
        System.out.println("Du får ingen poäng för den här frågan.");
        System.out.println();
    }
}
