package TheGame;

public class QuizSpelet {

    static GameStart playGame = new GameStart();

    
    public static void main(String[] args) {
    
           playGame.StartGame();
}
    
}
