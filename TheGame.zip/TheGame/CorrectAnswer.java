package TheGame;

public class CorrectAnswer extends Answer {
    public CorrectAnswer(String answerText) {
        super(answerText);
    }
}
