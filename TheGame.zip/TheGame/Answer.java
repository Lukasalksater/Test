package TheGame;

public class Answer {
    protected String answerText;

    public Answer(String answerText) {
        this.answerText = answerText;
    }

    public String getAnswerText() {
        return answerText;
    }
}
